read -p "Enter a decimal number less than 10000: " dec

if [ "$dec" -ge 10000 ]; then
	echo "Error: Number must be less than 10000." > "conversion result.txt"
	exit 1
fi

	
to_binary() { 
	local n=$1
	local result=""
	while [ $n -gt 0 ]; do
		result=$((n % 2))$result
		n=$((n / 2))
	done
	echo $result
}

to_hex() {
	local n=$1
	local result=""
	local hex_map=(0 1 2 3 4 5 6 7 8 9 A B C D E F)
	while [ $n -gt 0 ]; do
		digit=$((n % 16))
		result=${hex_map[$digit]}$result
		n=$((n / 16))
	done
	echo $result
}

binary=$(to_binary $dec)
hex=$(to_hex $dec)

echo "Decimal: $dec" > "convertion result.txt"
echo "Binary: $binary" >> "convertion result.txt"
echo "Hexadecimal: $hex" >> "convertion result.txt"
